package assignment2_f20;

import gradingTools.comp410f20.assignment2.testcases.Assignment2Suite;

public class RunTests {
  public static void main(String[] args){ //runs Assignment 2 oracle tests
    Assignment2Suite.main(args);
  }
}
