package assignment2_f20;

public interface Value {
	  public void setIdNum(int n);
	  public int getIdNum();
	  public void setScore(double s);
	  public double getScore();
	  public void setAge(int n);
	  public int getAge();
	}
