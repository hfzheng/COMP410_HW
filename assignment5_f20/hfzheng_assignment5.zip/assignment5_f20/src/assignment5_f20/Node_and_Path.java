package assignment5_f20;

public interface Node_and_Path {
	public void setNode(String newnode);
	public String getNode();
	public void setPath(long newdistance);
	public long getPath();
}
