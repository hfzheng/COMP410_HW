package assignment5_f20;

public interface Edge {
	public void setIdNum(long n);
	public long getIdNum();
	public void setsourceLabel(String newsourceLabel);
	public String getsourceLabel();
	public void setdestinLabel(String newdestinLabel);
	public String getdestinLabel();
	public void setweight(long newweight);
	public long getweight();
	public void setLabel(String newLabel);
	public String getLabel();

}

